# Flag Gates (Android)

250 country flags, bounce and spin at a calm steady pace inside a ring. The ring, the flags and the gate keep the same size from start to finish. The ring has ONE small exit gate that slowly travels around the ring. Two yellow blockers slide in to close it and slide out to open it, again and again. A flag that slips out while the gate is open is eliminated and drops into the ELIMINATED strip. The last flag left wins.

Features: 16 / 32 / 64 / 128 / 250 flag battles, gate speed, pick your own flag to cheer for, recent winners list, battle numbers, live counter + progress bar, 1x/2x/4x/8x speed, pause, sounds, vibration, works fully offline.

The game is HTML5 canvas, wrapped in a small native Android WebView app (`app/src/main/assets/www`).

## Get the APK - option A: no installs (GitHub Actions)

1. Create a free GitHub repository and upload everything in this folder (keep the `.github` folder).
2. Open the **Actions** tab, choose **Build Android APK**, press **Run workflow** (it also runs on every push).
3. When it finishes (about 3-5 min), open the run and download the **FlagGates-debug-apk** artifact. Unzip it and install `app-debug.apk` on your phone (allow "Install unknown apps").

## Get the APK - option B: Android Studio

1. Install Android Studio and choose **Open** on this folder.
2. Let Gradle sync, then **Build > Build APK(s)**. The file appears in `app/build/outputs/apk/debug/`.
3. Or plug in a phone and press **Run**.

## Publishing on Google Play

Create a signed **release** build (Build > Generate Signed App Bundle). Change `applicationId` in `app/build.gradle` to your own, e.g. `com.yourname.flaggates`.

## Customising

- Game code and styling: `app/src/main/assets/www/index.html`
- App name: `app/src/main/res/values/strings.xml`
- Icon: `app/src/main/res/drawable/ic_launcher_foreground.xml`
- Flag artwork: `flags.webp` is a sprite sheet (16 columns, 160x120 per flag) made from the MIT-licensed flag-icons project.
